# -*- coding: utf-8 -*-

print("Konnochiwa!")
